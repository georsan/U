function error_relativo_absoluto(valorR,valorA)
Ep=abs(valorR-valorA);
Rp=abs(valorR-valorA)/abs(valorR);
P='el error absoluto es:';
Q='el error relativo es:';
disp(P)
disp(Ep)
disp(Q)
disp(Rp)
end