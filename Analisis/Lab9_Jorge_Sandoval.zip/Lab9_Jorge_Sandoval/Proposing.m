fun=@(x)10-x;
a=2;
b=8;
M=8;


%%Simpson
I=my_simpson_function_Sandoval_Jorge(fun,a,b,M);
I

%%trapezoidal
i=my_trapezoidal_function_Sandoval_Jorge(fun,a,b,M);
i